package com.qingping.app

import android.content.ComponentName
import android.content.Context
import android.provider.Settings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/** 按应用统计拦截次数，存在本机 SharedPreferences 里。无障碍服务与界面同进程，用 StateFlow 通知刷新。 */
object Stats {

    data class Row(val pkg: String, val total: Int, val today: Int)

    private val _tick = MutableStateFlow(0)
    val tick: StateFlow<Int> = _tick

    private fun sp(c: Context) =
        c.applicationContext.getSharedPreferences("qingping", Context.MODE_PRIVATE)

    private fun day(offset: Int = 0): String {
        val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, offset) }
        return SimpleDateFormat("yyyyMMdd", Locale.US).format(cal.time)
    }

    /** 记一次拦截：累计 t:<包名>，当天 d:<日期>:<包名>。 */
    fun hit(c: Context, pkg: String) {
        val p = sp(c)
        val tk = "t:$pkg"
        val dk = "d:${day()}:$pkg"
        p.edit()
            .putInt(tk, p.getInt(tk, 0) + 1)
            .putInt(dk, p.getInt(dk, 0) + 1)
            .apply()
        _tick.value++
    }

    fun rows(c: Context): List<Row> {
        val all = sp(c).all
        val today = "d:${day()}:"
        return all.keys
            .filter { it.startsWith("t:") }
            .map { k ->
                val pkg = k.removePrefix("t:")
                Row(pkg, (all[k] as? Int) ?: 0, (all[today + pkg] as? Int) ?: 0)
            }
            .sortedByDescending { it.total }
    }

    /** 只保留最近 30 天的「每日」记录；累计数不动。 */
    fun prune(c: Context) {
        val cutoff = "d:${day(-30)}:"
        val p = sp(c)
        val e = p.edit()
        p.all.keys.filter { it.startsWith("d:") && it < cutoff }.forEach { e.remove(it) }
        e.apply()
    }

    fun clear(c: Context) {
        val p = sp(c)
        val e = p.edit()
        p.all.keys.filter { it.startsWith("t:") || it.startsWith("d:") }.forEach { e.remove(it) }
        e.apply()
        _tick.value++
    }

    fun refresh() {
        _tick.value++
    }

    fun guard(c: Context): Boolean = sp(c).getBoolean("s:guard", true)

    fun setGuard(c: Context, on: Boolean) {
        sp(c).edit().putBoolean("s:guard", on).apply()
    }

    /** 外观：0 跟随系统，1 浅色，2 深色。 */
    fun theme(c: Context): Int = sp(c).getInt("s:theme", 0)

    fun setTheme(c: Context, mode: Int) {
        sp(c).edit().putInt("s:theme", mode).apply()
    }
}

object Util {
    /** 无障碍服务是否已在系统设置里开启。 */
    fun isServiceEnabled(c: Context): Boolean {
        val cn = ComponentName(c, AdBlockService::class.java)
        val enabled = Settings.Secure.getString(
            c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.split(':').any {
            it.equals(cn.flattenToString(), ignoreCase = true) ||
                it.equals(cn.flattenToShortString(), ignoreCase = true)
        }
    }
}
