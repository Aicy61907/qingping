package com.qingping.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Path
import android.graphics.Rect
import android.net.Uri
import android.os.SystemClock
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * 清屏的核心：无障碍服务。
 *
 * 1) 开屏跳过：App 刚从桌面启动后的 SCAN_WINDOW_MS 内，扫描窗口里的「跳过 / 5s 跳过 / Skip」
 *    控件（按文字或 viewId 含 skip），找到后点击，并给该 App 记一次拦截。
 * 2) 误触跳转：App 从桌面启动后 JUMP_WINDOW_MS 内，如果「直接」拉起了浏览器 / 应用商店 / 其他第三方 App，
 *    判定为广告强制跳转，执行一次返回键并记一次拦截。
 *
 * 注意：这是启发式规则，只能「事后返回」，无法阻止跳转本身。
 */
class AdBlockService : AccessibilityService() {

    companion object {
        private const val SCAN_WINDOW_MS = 8_000L
        private const val JUMP_WINDOW_MS = 4_000L
        private const val SCAN_INTERVAL_MS = 200L
        private const val JUMP_COOLDOWN_MS = 3_000L

        // 「跳过」「5s 跳过」「跳过 5」「Skip」等；长度另在代码里限制，避免误点正文
        private val SKIP = Regex(
            """^\s*(\d{1,2}\s*[sS秒]?\s*[|｜·]?\s*)?(跳过广告|跳过|跳過|skip)(\s*[|｜·]?\s*\d{1,2}\s*[sS秒]?)?\s*$""",
            RegexOption.IGNORE_CASE
        )

        // 常见应用商店（系统自带，所以单独列出）
        private val STORES = setOf(
            "com.android.vending", "com.xiaomi.market", "com.huawei.appmarket",
            "com.heytap.market", "com.oppo.market", "com.bbk.appstore",
            "com.tencent.android.qqdownloader", "com.sec.android.app.samsungapps",
            "com.hihonor.appmarket"
        )
    }

    private var curPkg: String? = null
    private var curSince = 0L
    private var fromHome = false
    private var done = false
    private var lastScan = 0L
    private val jumpCool = HashMap<String, Long>()
    private var launchers: Set<String> = emptySet()
    private var browsers: Set<String> = emptySet()

    override fun onServiceConnected() {
        super.onServiceConnected()
        launchers = resolvePkgs(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME))
        browsers = resolvePkgs(
            Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com"))
                .addCategory(Intent.CATEGORY_BROWSABLE)
        )
        Stats.prune(this)
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        val ev = e ?: return
        val pkg = ev.packageName?.toString() ?: return
        if (isIgnored(pkg)) return
        try {
            when (ev.eventType) {
                AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> onWindow(pkg)
                AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> if (pkg == curPkg) scan(pkg)
            }
        } catch (t: Throwable) {
            // 无障碍服务必须保持存活：任何异常都不能向外抛，否则系统会把服务关掉
        }
    }

    // ---------------------------------------------------------------- 窗口切换

    private fun onWindow(pkg: String) {
        val now = SystemClock.elapsedRealtime()
        val prev = curPkg
        if (pkg != prev) {
            // 误触跳转：刚从桌面启动的 App，在 4 秒内直接把用户带去了别的 App
            if (prev != null && fromHome && prev !in launchers &&
                now - curSince < JUMP_WINDOW_MS &&
                Stats.guard(this) &&
                now - (jumpCool["j:$prev"] ?: 0L) > JUMP_COOLDOWN_MS &&
                isLanding(pkg)
            ) {
                jumpCool["j:$prev"] = now
                performGlobalAction(GLOBAL_ACTION_BACK)
                Stats.hit(this, prev)
                return // curPkg 仍然是 prev
            }
            fromHome = prev == null || prev in launchers
            curPkg = pkg
            curSince = now
            done = false
        }
        scan(pkg)
    }

    // ---------------------------------------------------------------- 开屏跳过

    private fun scan(pkg: String) {
        if (done || pkg in launchers) return
        val now = SystemClock.elapsedRealtime()
        if (now - curSince > SCAN_WINDOW_MS || now - lastScan < SCAN_INTERVAL_MS) return
        lastScan = now

        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != pkg) return
        val node = find(root, 0, IntArray(1)) ?: return
        if (click(node)) {
            done = true
            Stats.hit(this, pkg)
        }
    }

    private fun find(n: AccessibilityNodeInfo?, depth: Int, count: IntArray): AccessibilityNodeInfo? {
        if (n == null || depth > 30 || ++count[0] > 1500) return null
        if (n.isVisibleToUser && matches(n)) return n
        for (i in 0 until n.childCount) {
            find(n.getChild(i), depth + 1, count)?.let { return it }
        }
        return null
    }

    private fun matches(n: AccessibilityNodeInfo): Boolean {
        val t = (n.text ?: n.contentDescription)?.toString()
        if (t != null && t.length <= 12 && SKIP.matches(t)) return true

        // 没有文字时，退而看 viewId（各广告 SDK 的按钮 id 里通常带 skip），并限制控件面积，避免点到整屏广告
        val id = n.viewIdResourceName ?: return false
        if (!id.contains("skip", ignoreCase = true)) return false
        val r = Rect()
        n.getBoundsInScreen(r)
        val dm = resources.displayMetrics
        return !r.isEmpty &&
            r.width().toLong() * r.height() < dm.widthPixels.toLong() * dm.heightPixels / 10
    }

    private fun click(n: AccessibilityNodeInfo): Boolean {
        // 先沿父节点向上找可点击的控件
        var cur: AccessibilityNodeInfo? = n
        var i = 0
        while (cur != null && i < 5) {
            if (cur.isClickable && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            cur = cur.parent
            i++
        }
        // 兜底：在控件中心模拟一次手势点击
        val r = Rect()
        n.getBoundsInScreen(r)
        if (r.isEmpty) return false
        val path = Path().apply { moveTo(r.exactCenterX(), r.exactCenterY()) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 40))
            .build()
        return dispatchGesture(g, null, null)
    }

    // ---------------------------------------------------------------- 工具

    private fun isIgnored(pkg: String): Boolean =
        pkg == packageName || pkg == "com.android.systemui" || pkg == "android" || pkg == imePkg()

    private fun imePkg(): String? =
        Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
            ?.substringBefore('/')

    /** 浏览器、应用商店、或任何非系统的第三方 App 都算「落地页」；权限弹窗、设置等系统界面不算。 */
    private fun isLanding(pkg: String): Boolean {
        if (pkg in launchers) return false
        if (pkg in browsers || pkg in STORES) return true
        return try {
            (packageManager.getApplicationInfo(pkg, 0).flags and ApplicationInfo.FLAG_SYSTEM) == 0
        } catch (e: Exception) {
            false
        }
    }

    private fun resolvePkgs(i: Intent): Set<String> =
        packageManager.queryIntentActivities(i, PackageManager.MATCH_ALL)
            .map { it.activityInfo.packageName }
            .toSet()
}
