package com.qingping.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat

class MainActivity : ComponentActivity() {

    private var serviceOn by mutableStateOf(false)

    private val askNotif =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            askNotif.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent {
            Home(
                on = serviceOn,
                onEnable = { open(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
                onBattery = { open(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) },
                onInfo = {
                    open(
                        Intent(
                            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.fromParts("package", packageName, null)
                        )
                    )
                }
            )
        }
    }

    override fun onResume() {
        super.onResume()
        serviceOn = Util.isServiceEnabled(this)
        Stats.refresh()
    }

    private fun open(i: Intent) {
        try {
            startActivity(i)
        } catch (e: Exception) {
            // 个别 ROM 没有对应的设置页，忽略
        }
    }
}

// ============================================================ 瑞士风格设计令牌
// 纯黑、纯白、一个红色。红色只表示「状态」和「可操作」。
// 无衬线、左对齐、粗细对比做层级；用线条和网格分区，不用卡片、圆角和阴影。
// 深色模式 = 黑白互换：Ink 是「文字和线条的颜色」，Paper 是「底色」，在两套色板里各取一边。
private class Pal(val ink: Color, val paper: Color, val red: Color, val grey: Color, val hair: Color)

private val LightPal = Pal(
    ink = Color(0xFF000000), paper = Color(0xFFFFFFFF), red = Color(0xFFE3000F),
    grey = Color(0xFF767676), hair = Color(0xFFD9D9D9)
)
private val DarkPal = Pal(
    ink = Color(0xFFFFFFFF), paper = Color(0xFF000000), red = Color(0xFFFF3B47), // 红色在黑底上略提亮以保证可读
    grey = Color(0xFF9A9A9A), hair = Color(0xFF333333)
)
private val LocalPal = staticCompositionLocalOf { LightPal }

private val Ink: Color
    @Composable get() = LocalPal.current.ink
private val Paper: Color
    @Composable get() = LocalPal.current.paper
private val Red: Color
    @Composable get() = LocalPal.current.red
private val Grey: Color
    @Composable get() = LocalPal.current.grey
private val Hair: Color
    @Composable get() = LocalPal.current.hair
private val Sans = FontFamily.SansSerif // 想要 Helvetica 质感：把 Inter 放进 res/font 后在这里替换
private val LabelW = 76.dp // 左侧标签栏宽度：全页共用同一根网格线

@Composable
fun Home(on: Boolean, onEnable: () -> Unit, onBattery: () -> Unit, onInfo: () -> Unit) {
    val ctx = LocalContext.current
    var mode by remember { mutableStateOf(Stats.theme(ctx)) } // 0 跟随系统，1 浅色，2 深色
    val dark = when (mode) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }

    // 状态栏、导航栏的图标颜色跟随当前外观，否则深色模式下白字会落在白底上
    val view = LocalView.current
    SideEffect {
        val bars = WindowCompat.getInsetsController((view.context as Activity).window, view)
        bars.isAppearanceLightStatusBars = !dark
        bars.isAppearanceLightNavigationBars = !dark
    }

    CompositionLocalProvider(LocalPal provides if (dark) DarkPal else LightPal) {
        HomeBody(
            on = on,
            mode = mode,
            onMode = {
                mode = (mode + 1) % 3
                Stats.setTheme(ctx, mode)
            },
            onEnable = onEnable,
            onBattery = onBattery,
            onInfo = onInfo
        )
    }
}

@Composable
private fun HomeBody(
    on: Boolean,
    mode: Int,
    onMode: () -> Unit,
    onEnable: () -> Unit,
    onBattery: () -> Unit,
    onInfo: () -> Unit
) {
    val ctx = LocalContext.current
    val tick by Stats.tick.collectAsState()
    val rows = remember(tick) { Stats.rows(ctx) }
    var guard by remember { mutableStateOf(Stats.guard(ctx)) }
    val total = rows.sumOf { it.total }
    val today = rows.sumOf { it.today }
    val peak = (rows.maxOfOrNull { it.total } ?: 1).coerceAtLeast(1)

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(Paper).systemBarsPadding(),
        contentPadding = PaddingValues(horizontal = 24.dp, vertical = 20.dp)
    ) {
        item { Masthead() }
        item { Section("状态", "Status") { StatusBlock(on, onEnable) } }
        item {
            Section("已拦截", "Blocked") {
                Row(verticalAlignment = Alignment.Bottom) {
                    T("$total", 104, FontWeight.Black, ls = -5.0, lh = 100)
                    Spacer(Modifier.width(8.dp))
                    T("次", 22, FontWeight.Bold, Red, Modifier.padding(bottom = 12.dp))
                }
            }
        }
        item { Section("今日", "Today") { T("$today", 40, FontWeight.Bold) } }
        item { Section("应用", "Apps") { T("${rows.size}", 40, FontWeight.Bold) } }
        item {
            Section("按应用", "By app") {
                if (rows.isEmpty()) {
                    T("暂无记录。开启服务后，每次拦截都会记在这里。", 14, c = Grey, lh = 20)
                } else {
                    rows.forEachIndexed { i, r -> AppRow(i + 1, r, peak) }
                }
            }
        }
        item {
            Section("设置", "Settings") {
                ToggleRow("拦截误触跳转", "启动 4 秒内被强制拉起浏览器或其他应用时，自动返回", guard) {
                    guard = it
                    Stats.setGuard(ctx, it)
                }
                LinkRow("外观", "点按切换：跟随系统、浅色、深色", listOf("跟随系统", "浅色", "深色")[mode]) { onMode() }
                LinkRow("电池不受限制", "避免被系统清理后台", "前往", onBattery)
                LinkRow("允许受限制的设置", "侧载安装后，开启无障碍前需要", "前往", onInfo)
                LinkRow("清零统计", "删除本机全部拦截记录", "清零") { Stats.clear(ctx) }
            }
        }
        item {
            Column {
                Rule(1.dp)
                Spacer(Modifier.height(12.dp))
                T("所有处理均在本机完成，不联网。", 12, c = Grey)
            }
        }
    }
}

// ============================================================ 组件

@Composable
private fun Masthead() {
    Column {
        T("清屏", 88, FontWeight.Black, ls = -4.0, lh = 88)
        Spacer(Modifier.height(6.dp))
        T("开屏广告自动跳过", 15, FontWeight.Bold)
        T("Splash-ad skipper", 13, c = Grey)
        Spacer(Modifier.height(16.dp))
        Rule(8.dp)
        Spacer(Modifier.height(0.dp))
    }
}

/** 左窄右宽的两栏网格：左栏放标签（中文 + 英文小字），右栏放内容。 */
@Composable
private fun Section(zh: String, en: String, content: @Composable ColumnScope.() -> Unit) {
    Column {
        Rule(1.dp)
        Row(Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 22.dp)) {
            Column(Modifier.width(LabelW)) {
                T(zh, 13, FontWeight.Bold)
                T(en, 11, c = Grey)
            }
            Column(Modifier.weight(1f), content = content)
        }
    }
}

@Composable
private fun StatusBlock(on: Boolean, onEnable: () -> Unit) {
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(12.dp).background(if (on) Red else Grey))
            Spacer(Modifier.width(10.dp))
            T(if (on) "运行中" else "未启用", 18, FontWeight.Bold)
        }
        if (!on) {
            Spacer(Modifier.height(16.dp))
            Box(Modifier.fillMaxWidth().background(Ink).tap(onEnable).padding(16.dp)) {
                T("开启无障碍服务", 15, FontWeight.Bold, Paper)
            }
            Spacer(Modifier.height(10.dp))
            T("系统设置，无障碍，已安装的应用，清屏。侧载安装时需先允许受限制的设置。", 12, c = Grey, lh = 17)
        }
    }
}

@Composable
private fun AppRow(rank: Int, r: Stats.Row, peak: Int) {
    val pm = LocalContext.current.packageManager
    val name = remember(r.pkg) {
        try {
            pm.getApplicationLabel(pm.getApplicationInfo(r.pkg, 0)).toString()
        } catch (e: Exception) {
            r.pkg
        }
    }
    Column(Modifier.fillMaxWidth().padding(bottom = 18.dp)) {
        Row(verticalAlignment = Alignment.Bottom) {
            T("$rank", 11, c = Grey, m = Modifier.width(20.dp).padding(bottom = 3.dp))
            Column(Modifier.weight(1f)) {
                T(name, 16, FontWeight.Bold, lines = 1)
                T(r.pkg, 11, c = Grey, lines = 1)
            }
            Column(horizontalAlignment = Alignment.End) {
                T("${r.total}", 28, FontWeight.Black)
                T("今日 ${r.today}", 11, c = Grey)
            }
        }
        Spacer(Modifier.height(8.dp))
        // 条形长度 = 该应用拦截数 / 最大值
        Box(Modifier.fillMaxWidth().height(4.dp).background(Hair)) {
            Box(Modifier.fillMaxWidth(r.total.toFloat() / peak).height(4.dp).background(Red))
        }
    }
}

@Composable
private fun ToggleRow(title: String, sub: String, on: Boolean, onChange: (Boolean) -> Unit) {
    Column {
        Row(
            Modifier.fillMaxWidth().tap { onChange(!on) }.padding(bottom = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(Modifier.weight(1f).padding(end = 12.dp)) {
                T(title, 16, FontWeight.Bold)
                T(sub, 12, c = Grey, lh = 17)
            }
            Box(Modifier.size(24.dp).background(if (on) Red else Paper).border(2.dp, Ink))
        }
        Rule(1.dp, Hair)
    }
}

@Composable
private fun LinkRow(title: String, sub: String, action: String, onClick: () -> Unit) {
    Column {
        Row(
            Modifier.fillMaxWidth().tap(onClick).padding(vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(Modifier.weight(1f).padding(end = 12.dp)) {
                T(title, 16, FontWeight.Bold)
                T(sub, 12, c = Grey, lh = 17)
            }
            T(action, 13, FontWeight.Bold, Red)
        }
        Rule(1.dp, Hair)
    }
}

@Composable
private fun Rule(h: Dp = 1.dp, c: Color = Ink) {
    Box(Modifier.fillMaxWidth().height(h).background(c))
}

@Composable
private fun T(
    s: String,
    size: Int,
    w: FontWeight = FontWeight.Normal,
    c: Color = Ink,
    m: Modifier = Modifier,
    ls: Double = 0.0,
    lh: Int = 0,
    lines: Int = Int.MAX_VALUE
) {
    Text(
        text = s,
        modifier = m,
        color = c,
        fontFamily = Sans,
        fontSize = size.sp,
        fontWeight = w,
        letterSpacing = ls.sp,
        lineHeight = if (lh > 0) lh.sp else TextUnit.Unspecified,
        maxLines = lines
    )
}

@Composable
private fun Modifier.tap(onClick: () -> Unit): Modifier =
    this.clickable(
        interactionSource = remember { MutableInteractionSource() },
        indication = null,
        onClick = onClick
    )
